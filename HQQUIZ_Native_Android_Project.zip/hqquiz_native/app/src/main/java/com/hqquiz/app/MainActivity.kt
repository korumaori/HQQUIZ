package com.hqquiz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF020617)
private val Panel = Color(0xFF111C32)
private val Accent = Color(0xFF6366F1)
private data class QuizQuestion(val id:String,val level:String,val q:String,val opts:List<String>,val answer:String,val exp:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("hqquiz", MODE_PRIVATE)
        val bank = loadQuestions()
        setContent { HQQuizApp(bank, prefs) }
    }
    private fun loadQuestions(): List<JSONObject> {
        val raw = assets.open("questions.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }
}

@Composable
private fun HQQuizApp(bank:List<JSONObject>, prefs:android.content.SharedPreferences) {
    var lang by remember { mutableStateOf(prefs.getString("lang","en") ?: "en") }
    var screen by remember { mutableStateOf("home") }
    var level by remember { mutableStateOf("easy") }
    var round by remember { mutableStateOf(listOf<QuizQuestion>()) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var best by remember { mutableIntStateOf(prefs.getInt("best",0)) }
    val ar = lang == "ar"
    fun tr(en:String, arabic:String, french:String="") = when(lang) { "ar" -> arabic; "fr" -> french.ifBlank { en }; else -> en }
    fun start(l:String) {
        level=l; index=0; selected=null; score=0
        val eligible=bank.filter { it.optString("level")==l }.shuffled().take(10)
        round=eligible.map { item ->
            val loc= item.optJSONObject(lang) ?: item.getJSONObject("en")
            val opts=loc.getJSONArray("opts")
            val original=(0 until opts.length()).map { opts.getString(it) }
            val correctIndex=item.optInt("ans",0).coerceIn(0,original.lastIndex)
            val correct=original[correctIndex]
            val shuffled=original.shuffled()
            QuizQuestion(item.optString("id"),l,loc.optString("q"),shuffled,correct,loc.optString("exp"))
        }
        screen="quiz"
    }
    MaterialTheme(colorScheme=darkColorScheme(primary=Accent,background=Bg,surface=Panel,onBackground=Color.White,onSurface=Color.White)) {
        Surface(modifier=Modifier.fillMaxSize(), color=Bg) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("HQQUIZ",fontSize=32.sp,fontWeight=FontWeight.Black,color=Color.White)
                Text("CHALLENGE YOUR MIND",fontSize=11.sp,letterSpacing=3.sp,color=Color(0xFF9CA3AF))
                Spacer(Modifier.height(20.dp))
                when(screen) {
                    "home" -> {
                        Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                Text(tr("Ready to play?","هل أنت مستعد للعب؟","Prêt à jouer ?"),fontSize=22.sp,fontWeight=FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(tr("Choose your difficulty","اختر مستوى الصعوبة","Choisissez la difficulté"),color=Color.LightGray)
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    listOf("en" to "EN","ar" to "AR","fr" to "FR").forEach { (code,label) ->
                                        FilterChip(selected=lang==code,onClick={lang=code;prefs.edit().putString("lang",code).apply()},label={Text(label)})
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        listOf("easy","medium","hard").forEach { l ->
                            val title=when(l){"easy"->tr("Easy","سهل","Facile");"medium"->tr("Medium","متوسط","Moyen");else->tr("Hard","صعب","Difficile")}
                            Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().padding(vertical=6.dp).clickable { start(l) }) {
                                Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold); Text(tr("10 random questions","10 أسئلة عشوائية","10 questions aléatoires"),color=Color.LightGray,fontSize=12.sp) }
                                    Text("➜",fontSize=24.sp,color=Accent)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(tr("Best score: $best","أفضل نتيجة: $best","Meilleur score : $best"),color=Color(0xFFA5B4FC),fontSize=16.sp)
                        Text(tr("Works offline • Progress saved on this phone","يعمل دون إنترنت • يتم حفظ التقدم على الهاتف","Hors ligne • progression sauvegardée"),color=Color.Gray,fontSize=11.sp,textAlign=TextAlign.Center)
                    }
                    "quiz" -> {
                        if (round.isEmpty()) { Text(tr("No questions available","لا توجد أسئلة","Aucune question")) }
                        else {
                            val item=round[index]
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                Text("${index+1} / ${round.size}",color=Color.LightGray)
                                Text("${tr("Score","النقاط","Score")}: $score",color=Color(0xFFA5B4FC),fontWeight=FontWeight.Bold)
                            }
                            LinearProgressIndicator(progress={(index+1).toFloat()/round.size},modifier=Modifier.fillMaxWidth().padding(vertical=12.dp),color=Accent)
                            Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(20.dp)) {
                                    Text(item.q,fontSize=21.sp,fontWeight=FontWeight.Bold,textAlign=if(ar)TextAlign.End else TextAlign.Start,modifier=Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(20.dp))
                                    item.opts.forEachIndexed { i,opt ->
                                        val bg=when { selected==null -> Color(0xFF1E293B); opt==item.answer -> Color(0xFF14532D); selected==opt -> Color(0xFF7F1D1D); else -> Color(0xFF1E293B) }
                                        Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(bg,RoundedCornerShape(13.dp)).clickable(enabled=selected==null){selected=opt;if(opt==item.answer){score++}},verticalAlignment=Alignment.CenterVertically) {
                                            Text("${('A'.code+i).toChar()}",color=Color(0xFFA5B4FC),fontWeight=FontWeight.Bold,modifier=Modifier.padding(14.dp))
                                            Text(opt,modifier=Modifier.weight(1f).padding(vertical=14.dp,end=12.dp),fontSize=15.sp)
                                        }
                                    }
                                    if(selected!=null) {
                                        Spacer(Modifier.height(12.dp))
                                        Text(if(selected==item.answer)tr("Correct!","إجابة صحيحة!","Correct !") else tr("Not quite","إجابة غير صحيحة","Incorrect"),fontWeight=FontWeight.Bold,color=if(selected==item.answer)Color(0xFF4ADE80) else Color(0xFFFCA5A5))
                                        Text(item.exp,color=Color.LightGray,fontSize=13.sp)
                                        Spacer(Modifier.height(10.dp))
                                        Button(onClick={ if(index<round.lastIndex){index++;selected=null}else{total+=score;val newBest=maxOf(best,score);best=newBest;prefs.edit().putInt("best",best).putInt("total",total).apply();screen="result"} },modifier=Modifier.fillMaxWidth()) { Text(if(index<round.lastIndex)tr("Next question","السؤال التالي","Question suivante") else tr("Finish","إنهاء","Terminer")) }
                                    }
                                }
                            }
                            TextButton(onClick={screen="home"}) { Text(tr("Exit quiz","الخروج من الاختبار","Quitter le quiz"),color=Color.LightGray) }
                        }
                    }
                    "result" -> {
                        Spacer(Modifier.height(40.dp)); Text("🏆",fontSize=56.sp)
                        Text(tr("Challenge complete!","أكملت التحدي!","Défi terminé !"),fontSize=25.sp,fontWeight=FontWeight.Bold)
                        Text("$score / ${round.size}",fontSize=42.sp,color=Color(0xFFA5B4FC),fontWeight=FontWeight.Black)
                        Text(tr("Your best score: $best","أفضل نتيجة: $best","Votre meilleur score : $best"),color=Color.LightGray)
                        Spacer(Modifier.height(20.dp))
                        Button(onClick={start(level)},modifier=Modifier.fillMaxWidth()) { Text(tr("Play again","العب مجدداً","Rejouer")) }
                        OutlinedButton(onClick={screen="home"},modifier=Modifier.fillMaxWidth()) { Text(tr("Home","الرئيسية","Accueil")) }
                    }
                }
            }
        }
    }
}
