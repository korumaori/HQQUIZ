# HQQUIZ — Native Android starter

This is a native Kotlin + Jetpack Compose Android project. It does not use WebView, a server, a database, or internet permission.

## Included in this first build
- Native Android screen and navigation (home, quiz, result)
- Easy / Medium / Hard; 10 randomly selected questions per round
- Answer choices are shuffled independently for every question
- Score and best score saved locally with SharedPreferences
- Arabic, English, and French question text where available
- Offline question bank bundled in `app/src/main/assets/questions.json`

## Question-bank audit
The supplied HTML contained 1,000 records. 530 records used mechanically generated placeholder wording (for example “item 231” / “partie 231”), so this project excludes those placeholder records rather than presenting them as genuine quiz questions. 470 source questions remain: 155 easy, 160 medium, 155 hard. The remaining content still needs editorial fact-checking before public release.

## Build
Open this folder as an Android project in Android Studio, or use the included GitHub Actions workflow. On GitHub, upload/push this project to a repository, then open **Actions → Build HQQUIZ Android APK → Run workflow**. Download the `HQQUIZ-debug-apk` artifact after the run completes.

The current source package has not yet been compiled or device-tested. The workflow creates a debug APK for testing; a Play Store release requires a separately configured release signing key and a release build.
